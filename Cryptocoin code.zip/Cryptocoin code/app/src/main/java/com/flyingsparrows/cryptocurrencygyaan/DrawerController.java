package com.flyingsparrows.cryptocurrencygyaan;


public interface DrawerController {
    void hideHamburger();
    void showHamburger();
}
