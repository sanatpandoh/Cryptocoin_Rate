package com.flyingsparrows.cryptocurrencygyaan.models.rest;


public class WatchList {

    private String CoinIs;
    private String Sponsored;

    public String getCoinIs() {
        return CoinIs;
    }

    public void setCoinIs(String coinIs) {
        CoinIs = coinIs;
    }

    public String getSponsored() {
        return Sponsored;
    }

    public void setSponsored(String sponsored) {
        Sponsored = sponsored;
    }

}
