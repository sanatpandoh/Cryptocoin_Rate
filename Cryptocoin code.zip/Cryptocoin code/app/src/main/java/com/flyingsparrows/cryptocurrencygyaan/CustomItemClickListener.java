package com.flyingsparrows.cryptocurrencygyaan;

import android.view.View;


public interface CustomItemClickListener {
    void onItemClick(int position, View v);
}
