package com.flyingsparrows.cryptocurrencygyaan;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.jaredrummler.android.device.DeviceName;
import com.vansuita.materialabout.builder.AboutBuilder;
import com.vansuita.materialabout.views.AboutView;


public class AboutTheDevActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AboutView view = AboutBuilder.with(this)
                .setPhoto(R.mipmap.programmer)
                .setCover(R.mipmap.background_material_design)
                .setName("Ayushi Sangra")
                .setSubTitle("Mobile Developer")
                .setBrief("Innovator, dreamer, and boundary pusher with a deep passion for mobile app development")
                .setAppIcon(R.mipmap.ic_launcher)
                .setAppName(R.string.app_name)
                .setVersionNameAsAppSubTitle()
                .setWrapScrollView(true)
                .setLinksAnimated(true)
                .setShowAsCard(true)
                .setAppIcon(R.mipmap.ic_launcher)
                .addEmailLink("rybridges16@gmail.com")
                .addFacebookLink("ayushi.sangra.3")
                .addFeedbackAction("ayushisangra11@gmail.com")
                .build();
        setContentView(view);
    }
}
